import math

import math


def my_abs(value):
    return math.fabs(value)


def my_pow(a, b):
    return math.pow(a, b)


def silnia(n):
    return math.factorial(n)


def iloczyn_skalarny(lista):
    return math.prod(lista)
